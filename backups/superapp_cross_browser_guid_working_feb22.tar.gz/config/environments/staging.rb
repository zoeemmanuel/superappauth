Rails.application.configure do
  config.cache_classes = true
  config.eager_load = true
  config.consider_all_requests_local = true
  
  # Asset handling - consolidated
  config.assets.compile = true
  config.assets.digest = true
  config.assets.version = '1.0'
  config.assets.prefix = '/assets'
  config.serve_static_assets = true
  config.assets.compile = true
  config.public_file_server.enabled = true
  
  # Add these specific asset configurations
  config.assets.paths << Rails.root.join('public', 'assets')
  config.assets.paths << Rails.root.join('app', 'assets', 'builds')
  
  # Logging
  config.log_level = :debug
  config.logger = Logger.new(Rails.root.join('log', 'staging.log'))
  
  # Allow all hosts
  config.hosts = nil
end
