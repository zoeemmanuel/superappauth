const generateDeviceKey = async () => {
    try {
        const array = new Uint8Array(32);
        crypto.getRandomValues(array);
        const key = Array.from(array)
            .map(b => b.toString(16).padStart(2, '0'))
            .join('');
        return key;
    } catch (err) {
        console.error('Failed to generate device key:', err);
        return null;
    }
};

const getStoredDeviceKey = async () => {
    // Only check sessionStorage - don't make API calls here
    const sessionKey = sessionStorage.getItem('device_key');
    if (sessionKey) {
        console.log('Found key in session');
        return sessionKey;
    }
    return null;
};

const storeDeviceKey = (key) => {
    if (key) {
        sessionStorage.setItem('device_key', key);
        console.log('Stored device key:', key);
    }
};

module.exports = {
    generateDeviceKey,
    getStoredDeviceKey,
    storeDeviceKey
};
