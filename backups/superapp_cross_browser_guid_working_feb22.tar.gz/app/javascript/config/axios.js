const axios = require('axios');
const { generateDeviceKey, getStoredDeviceKey, storeDeviceKey } = require('../utils/deviceKey');

const instance = axios.create({
 baseURL: '/api/v1/auth',  
  headers: {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
  }
});

instance.interceptors.request.use(async config => {
  try {
    console.log('Starting request interceptor');
    const url = config.url;
    console.log('Request URL:', url);
    
    // Always add CSRF token if available
    if (window.csrfToken) {
      config.headers['X-CSRF-Token'] = window.csrfToken;
      console.log('Added CSRF token to headers');
    }

    // Don't add device key to check_device requests to avoid circular calls
    if (!url.endsWith('/check_device')) {
      let deviceKey = sessionStorage.getItem('device_key');
      console.log('Retrieved device key:', deviceKey ? deviceKey.substring(0, 10) + '...' : 'none');
      
      if (!deviceKey) {
        console.log('No device key found - generating new one');
        deviceKey = await generateDeviceKey();
        if (deviceKey) {
          console.log('Generated new device key:', deviceKey.substring(0, 10) + '...');
          sessionStorage.setItem('device_key', deviceKey);
        }
      }
      
      if (deviceKey) {
        config.headers['X-Device-Key'] = deviceKey;
        console.log('Added device key to headers');
      }
    }
    
    console.log('Final request headers:', config.headers);
    return config;
  } catch (error) {
    console.error('Request interceptor error:', error);
    return config;
  }
});

instance.interceptors.response.use(
  response => {
    if (response.data?.device_key) {
      storeDeviceKey(response.data.device_key);
      console.log('Stored device key from response');
    }
    return response;
  },
  error => {
    console.error('Response error:', {
      status: error.response?.status,
      data: error.response?.data,
      headers: error.config?.headers
    });
    return Promise.reject(error);
  }
);

module.exports = instance;
