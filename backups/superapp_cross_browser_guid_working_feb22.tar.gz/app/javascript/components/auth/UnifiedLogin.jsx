const React = require('react');
const { useState, useEffect } = React;
const { X } = require('lucide-react');
const axios = require('../../config/axios');
const { generateDeviceKey, getStoredDeviceKey, storeDeviceKey } = require('../../utils/deviceKey');

const UnifiedLogin = () => {
  const [step, setStep] = useState('checking');
  const [identifier, setIdentifier] = useState('');
  const [verificationCode, setVerificationCode] = useState('');
  const [handle, setHandle] = useState('');
  const [error, setError] = useState('');
  const [phone, setPhone] = useState('');
  const [isQuickVerification, setIsQuickVerification] = useState(false);
  const [countryCode, setCountryCode] = useState('+44');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [showCountrySelect, setShowCountrySelect] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [redirectAttempts, setRedirectAttempts] = useState(0);
  const MAX_REDIRECT_ATTEMPTS = 3;

  useEffect(() => {
    checkDevice();
  }, []);

  useEffect(() => {
    if (verificationCode.length === 6) {
      handleVerificationSubmit();
    }
  }, [verificationCode]);

  const checkDevice = async () => {
    try {
        let deviceKey = await getStoredDeviceKey();
        
        if (!deviceKey) {
            console.log('No device key found, generating...');
            deviceKey = await generateDeviceKey();
            if (deviceKey) {
                console.log('Storing new device key');
                storeDeviceKey(deviceKey);
            }
        }

        const response = await axios.post('check_device', {}, {
            headers: deviceKey ? {
                'X-Device-Key': deviceKey,
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            } : {}
        });

        console.log('Check device response:', response.data);

        if (response.data.device_key) {
            storeDeviceKey(response.data.device_key);
        }

        if (response.data.status === 'authenticated') {
            window.location.href = response.data.redirect_to;
        } else if (response.data.status === 'needs_quick_verification') {
            setHandle(response.data.handle);
            setPhone(response.data.masked_phone);
            setIsQuickVerification(true);
            setStep('verify');
        } else {
            if (response.data.guid) {
                sessionStorage.setItem('device_guid', response.data.guid);
            }
            setStep('initial');
        }
    } catch (err) {
        console.error('Device check failed:', err);
        setError('Device check failed');
        setStep('initial');
    }
  };

  const handlePhoneInput = (e) => {
    const value = e.target.value.replace(/[^\d]/g, '');
    setPhoneNumber(value);
    const fullNumber = `${countryCode}${value}`;
    setIdentifier(fullNumber);
  };

  const formatPhoneDisplay = (number) => {
    if (!number) return '';
    const digits = number.replace(/[^\d]/g, '');
    
    if (countryCode === '+44') { // UK format
      if (digits.length <= 4) return digits;
      if (digits.length <= 7) return `${digits.slice(0, 4)} ${digits.slice(4)}`;
      return `${digits.slice(0, 4)} ${digits.slice(4, 7)} ${digits.slice(7)}`;
    } else { // Singapore format
      if (digits.length <= 4) return digits;
      return `${digits.slice(0, 4)} ${digits.slice(4)}`;
    }
  };

  const validatePhoneNumber = () => {
    if (countryCode === '+44' && phoneNumber.length !== 10) return false;
    if (countryCode === '+65' && phoneNumber.length !== 8) return false;
    return true;
  };

  const handleSubmit = async () => {
    setError('');
    
    if (!identifier.startsWith('@') && !validatePhoneNumber()) {
      setError(`Please enter a valid ${countryCode === '+44' ? 'UK' : 'Singapore'} phone number`);
      return;
    }
    
    try {
      const deviceKey = await getStoredDeviceKey();
      console.log('Submitting verification request:', {
        url: 'verify_login',
        data: { identifier },
        deviceKey
      });

      const response = await axios.post('verify_login', {
        identifier: identifier,
        auth: { identifier: identifier }
      }, {
        headers: {
          'X-Device-Key': deviceKey,
          'X-CSRF-Token': window.csrfToken,
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        }
      });

      console.log('Verification response:', response.data);

      if (response.data.status === 'verification_needed') {
        setHandle(response.data.handle || '');
        setPhone(response.data.masked_phone);
        setStep('verify');
      }
    } catch (err) {
      console.error('Verification error:', {
        status: err.response?.status,
        data: err.response?.data,
        headers: err.config?.headers,
        url: err.config?.url,
        requestData: err.config?.data
      });
      
      if (err.response?.status === 404) {
        try {
          const deviceKey = await getStoredDeviceKey();
          const response = await axios.post('verify_login', {
            identifier: identifier
          }, {
            headers: {
              'X-Device-Key': deviceKey,
              'X-CSRF-Token': window.csrfToken,
              'Accept': 'application/json',
              'Content-Type': 'application/json'
            }
          });

          if (response.data.status === 'verification_needed') {
            setHandle(response.data.handle || '');
            setPhone(response.data.masked_phone);
            setStep('verify');
          }
        } catch (retryErr) {
          console.error('Retry verification error:', {
            status: retryErr.response?.status,
            data: retryErr.response?.data,
            headers: retryErr.config?.headers,
            url: retryErr.config?.url,
            requestData: retryErr.config?.data
          });
          
          if (retryErr.response?.data?.status === 'handle_not_found') {
            setError('This username is not registered. Please register with your phone number.');
            setIdentifier('');
          } else {
            setError(retryErr.response?.data?.error || 'Verification failed');
          }
        }
      } else if (err.response?.data?.status === 'handle_not_found') {
        setError('This username is not registered. Please register with your phone number.');
        setIdentifier('');
      } else {
        setError(err.response?.data?.error || 'Verification failed');
      }
    }
  };
const handleHandleSubmit = async () => {
    if (isLoading) return;
    setIsLoading(true);
    setError('');
    
    try {
      const deviceKey = await getStoredDeviceKey();
      const response = await axios.post('create_handle', {
        handle,
        phone: phone
      }, {
        headers: {
          'X-Device-Key': deviceKey
        }
      });

      console.log('Handle creation response:', response.data);

      if (response.data.status === 'authenticated') {
        if (response.data.device_key) {
          storeDeviceKey(response.data.device_key);
        }

        const attemptRedirect = async () => {
          if (redirectAttempts >= MAX_REDIRECT_ATTEMPTS) {
            setError('Unable to redirect. Please refresh the page.');
            setIsLoading(false);
            return;
          }

          try {
            const response = await axios.get('check_status', {
              headers: { 'X-Device-Key': deviceKey }
            });
            
            if (response.data.status === 'authenticated') {
              window.location.href = '/dashboard';
              return;
            }
            
            setRedirectAttempts(prev => prev + 1);
            setTimeout(attemptRedirect, 1000);
          } catch (err) {
            console.error('Auth check failed:', err);
            setRedirectAttempts(prev => prev + 1);
            setTimeout(attemptRedirect, 1000);
          }
        };

        attemptRedirect();
      }
    } catch (err) {
      console.error('Handle creation error:', err);
      setError(err.response?.data?.error || 'Failed to create handle');
      setIsLoading(false);
    }
  };

  const handleVerificationSubmit = async () => {
    if (verificationCode.length !== 6) return;

    try {
      const deviceKey = await getStoredDeviceKey();
      const payload = isQuickVerification 
        ? { code: verificationCode }
        : { code: verificationCode, phone: identifier };

      const response = await axios.post('verify_code', payload, {
        headers: {
          'X-Device-Key': deviceKey
        }
      });

      if (response.data.status === 'authenticated') {
        if (response.data.device_key) {
          storeDeviceKey(response.data.device_key);
        }
        window.location.href = response.data.redirect_to;
      } else if (response.data.status === 'needs_handle') {
        setStep('create_handle');
      }
    } catch (err) {
      setError(err.response?.data?.error || 'Invalid verification code');
      setVerificationCode('');
    }
  };

  const formatPhoneNumber = (value) => {
    if (!value) return value;
    const phoneNumber = value.replace(/[^\d+]/g, '');
    if (phoneNumber.startsWith('44')) return `+${phoneNumber}`;
    if (phoneNumber.startsWith('65')) return `+${phoneNumber}`;
    if (phoneNumber.startsWith('4')) return `+4${phoneNumber}`;
    if (phoneNumber.startsWith('6')) return `+6${phoneNumber}`;
    return phoneNumber;
  };

  const handlePhoneChange = (e) => {
    const formattedPhone = formatPhoneNumber(e.target.value);
    setIdentifier(formattedPhone);
  };

  const renderVerificationStep = () => (
    <div className="min-h-screen bg-gray-900 text-white flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="mb-8 flex justify-center">
          <div className="w-16 h-16 rounded-full bg-teal-500 flex items-center justify-center text-xl font-bold">
            {handle ? handle[0].toUpperCase() : 'S'}
          </div>
        </div>

        <div className="text-center space-y-2 mb-8">
          <h1 className="text-2xl font-bold">
            {isQuickVerification ? `Welcome back, ${handle}` : (handle ? `Welcome back, ${handle}` : 'Verify your number')}
          </h1>
          <p className="text-gray-400">
            {isQuickVerification ? (
              <>
                Quick verification required for this device
                <br />
                Enter the code sent to {phone}
              </>
            ) : (
              `Enter the code sent to ${phone}`
            )}
          </p>
        </div>

        <div className="mb-12">
          <div className="flex justify-center gap-3">
            {[...Array(6)].map((_, i) => (
              <div
                key={i}
                className={`w-12 h-14 flex items-center justify-center text-xl 
                  border-2 rounded-lg transition-colors
                  ${verificationCode[i] ? 'border-teal-500 bg-gray-800' : 'border-gray-600'}`}
              >
                {verificationCode[i] || ''}
              </div>
            ))}
          </div>
          
          <input
            type="tel"
            value={verificationCode}
            onChange={(e) => {
              const value = e.target.value.replace(/[^0-9]/g, '').slice(0, 6);
              setVerificationCode(value);
            }}
            className="sr-only"
            maxLength={6}
            autoFocus
          />
        </div>

        <div className="grid grid-cols-3 gap-6 mb-8">
          {[1,2,3,4,5,6,7,8,9,'',0,'⌫'].map((num, i) => (
            <button
              key={i}
              onClick={() => {
                if (num === '⌫') {
                  setVerificationCode(prev => prev.slice(0, -1));
                } else if (num !== '') {
                  setVerificationCode(prev => 
                    prev.length < 6 ? prev + num : prev
                  );
                }
              }}
              className={`h-14 text-2xl font-light rounded-full
                ${num === '' ? 'cursor-default' : 'hover:bg-gray-800 active:bg-gray-700'}`}
            >
              {num}
            </button>
          ))}
        </div>

        {error && (
          <div className="text-red-500 text-center mb-4 flex items-center justify-center">
            <span>{error}</span>
            <button onClick={() => setError('')} className="ml-2">
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        <button
          onClick={() => {
            setStep('initial');
            setVerificationCode('');
            setIsQuickVerification(false);
          }}
          className="text-sm text-gray-400 w-full text-center mt-4 hover:text-gray-300 transition-colors"
        >
          Didn't receive code?
        </button>
      </div>
    </div>
  );

  const renderInitialStep = () => (
    <div className="min-h-screen bg-gray-900 text-white flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-md space-y-8">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-2">Welcome to SuperApp</h1>
          <p className="text-gray-400">Enter your phone number or @handle</p>
        </div>

        <div className="relative">
          {!identifier.startsWith('@') ? (
            <div className="flex">
              <button 
                onClick={() => setShowCountrySelect(!showCountrySelect)}
                className="bg-gray-800 rounded-l-lg py-4 px-4 flex items-center gap-2 border-r border-gray-700"
              >
                {countryCode === '+44' ? '🇬🇧' : '🇸🇬'} {countryCode}
              </button>
              
              <input
                type="tel"
                value={formatPhoneDisplay(phoneNumber)}
                onChange={handlePhoneInput}
                placeholder={countryCode === '+44' ? "7XXX XXX XXX" : "XXXX XXXX"}
                className="flex-1 bg-gray-800 border-0 rounded-r-lg py-4 px-6 text-lg
                         focus:ring-2 focus:ring-teal-500 focus:outline-none"
              />
            </div>
          ) : (
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-6 flex items-center pointer-events-none">
                <span className="text-gray-400">@</span>
              </div>
              <input
                type="text"
                value={identifier.replace('@', '')}
                onChange={(e) => setIdentifier('@' + e.target.value.replace('@', ''))}
                placeholder="username"
                className="w-full bg-gray-800 border-0 rounded-lg py-4 pl-10 pr-6 text-lg
                         focus:ring-2 focus:ring-teal-500 focus:outline-none"
              />
            </div>
          )}

          {showCountrySelect && (
            <div className="absolute mt-2 w-32 bg-gray-800 rounded-lg shadow-lg z-10">
              <button 
                onClick={() => {
                  setCountryCode('+44');
                  setShowCountrySelect(false);
                  setPhoneNumber('');
                }}
                className="w-full px-4 py-3 text-left hover:bg-gray-700 flex items-center gap-2"
              >
                🇬🇧 +44
              </button>
              <button 
                onClick={() => {
                  setCountryCode('+65');
                  setShowCountrySelect(false);
                  setPhoneNumber('');
                }}
                className="w-full px-4 py-3 text-left hover:bg-gray-700 flex items-center gap-2"
              >
                🇸🇬 +65
              </button>
            </div>
          )}

          <button 
            onClick={() => {
              if (identifier.startsWith('@')) {
                setIdentifier('');
                setPhoneNumber('');
              } else {
                setIdentifier('@');
                setPhoneNumber('');
              }
            }}
            className="text-sm text-gray-400 mt-2 hover:text-gray-300"
          >
            {identifier.startsWith('@') ? 'Use phone number instead' : 'Use username instead'}
          </button>
        </div>

        <button
          onClick={handleSubmit}
          disabled={!identifier || (identifier.startsWith('@') ? identifier.length < 2 : !validatePhoneNumber())}
          className="w-full bg-teal-500 text-white rounded-lg py-4 font-medium
                   disabled:opacity-50 disabled:cursor-not-allowed
                   hover:bg-teal-600 transition-colors"
        >
          Continue
        </button>

        {error && (
          <div className="text-red-500 text-center flex items-center justify-center">
            <span>{error}</span>
            <button onClick={() => setError('')} className="ml-2">
              <X className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );

  const renderHandleCreation = () => (
    <div className="min-h-screen bg-gray-900 text-white flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-md space-y-8">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-2">Create your handle</h1>
          <p className="text-gray-400">This will be your unique identifier</p>
        </div>

        <div>
          <input
            type="text"
            value={handle}
            onChange={(e) => setHandle(e.target.value.startsWith('@') ? e.target.value : '@' + e.target.value)}
            placeholder="@username"
            className="w-full bg-gray-800 border-0 rounded-lg py-4 px-6 text-lg
                     focus:ring-2 focus:ring-teal-500 focus:outline-none"
            disabled={isLoading}
          />
        </div>

        <button
          onClick={handleHandleSubmit}
          disabled={!handle || handle.length < 2 || isLoading}
          className="w-full bg-teal-500 text-white rounded-lg py-4 font-medium
                   disabled:opacity-50 disabled:cursor-not-allowed
                   hover:bg-teal-600 transition-colors relative"
        >
          {isLoading ? (
            <div className="flex items-center justify-center">
              <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2" />
              Setting up your account...
            </div>
          ) : (
            'Create Handle'
          )}
        </button>

        {error && (
          <div className="text-red-500 text-center flex items-center justify-center">
            <span>{error}</span>
            <button onClick={() => setError('')} className="ml-2">
              <X className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );

  return (
    <>
      {step === 'checking' && (
        <div className="min-h-screen bg-gray-900 flex items-center justify-center">
          <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-teal-500" />
        </div>
      )}
      {step === 'initial' && renderInitialStep()}
      {step === 'verify' && renderVerificationStep()}
      {step === 'create_handle' && renderHandleCreation()}
    </>
  );
};

module.exports = UnifiedLogin;
