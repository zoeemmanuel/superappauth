class ApplicationController < ActionController::Base
  protect_from_forgery with: :exception
  after_action :set_csrf_token_header

  private

  def set_csrf_token_header
    response.headers['X-CSRF-Token'] = form_authenticity_token
  end

  def current_device
    @current_device ||= begin
      puts "========== CURRENT DEVICE CHECK =========="
      
      # First check session paths
      if session[:device_path]
        device = get_device_from_path(session[:device_path])
        return device if device
      end
      
      if session[:pending_device_path]
        device = get_device_from_path(session[:pending_device_path])
        return device if device
      end
      
      # If no session device, scan all devices
      puts "No device in session, scanning all devices..."
      scan_all_devices
    end
  end

  def get_device_from_path(device_path)
    puts "Checking device path: #{device_path}"
    return nil unless device_path

    full_path = Rails.root.join('db', device_path)
    puts "Full path: #{full_path}"
    return nil unless File.exist?(full_path)

    begin
      db = SQLite3::Database.new(full_path)
      device_info = db.get_first_row("SELECT device_id, handle, guid, phone, last_verified_at FROM device_info LIMIT 1")
      puts "Device info from DB: #{device_info.inspect}"
      
      if device_info && valid_device_identifiers?(device_info[0], device_info[2])
        sync_info = db.get_first_row("SELECT last_sync, status FROM sync_state ORDER BY id DESC LIMIT 1")
        db.close

        result = {
          device_id: device_info[0],
          handle: device_info[1],
          guid: device_info[2],
          phone: device_info[3],
          last_verified_at: device_info[4],
          path: device_path,
          sync_state: {
            last_sync: sync_info&.[](0),
            status: sync_info&.[](1)
          }
        }
        puts "Returning device info: #{result.inspect}"
        result
      else
        db.close
        puts "Invalid device identifiers"
        nil
      end
    rescue SQLite3::Exception => e
      puts "Database error in get_device_from_path: #{e.message}"
      nil
    end
  end

  def scan_all_devices
    puts "========== SCANNING ALL DEVICES =========="
    
    Dir.glob(Rails.root.join('db', 'devices', '*.sqlite3')).each do |db_path|
      puts "Checking device database: #{db_path}"
      begin
        db = SQLite3::Database.new(db_path)
        device_info = db.get_first_row("SELECT device_id, handle, guid, phone, last_verified_at FROM device_info LIMIT 1")
        sync_info = db.get_first_row("SELECT last_sync, status FROM sync_state ORDER BY id DESC LIMIT 1")
        db.close
        
        puts "Found device info: #{device_info.inspect}"
        next unless device_info
        next unless valid_device_identifiers?(device_info[0], device_info[2])
        
        relative_path = db_path.split('db/').last
        result = {
          device_id: device_info[0],
          handle: device_info[1],
          guid: device_info[2],
          phone: device_info[3],
          last_verified_at: device_info[4],
          path: relative_path,
          sync_state: {
            last_sync: sync_info&.[](0),
            status: sync_info&.[](1)
          }
        }
        puts "Found valid device: #{result.inspect}"
        return result
      rescue SQLite3::Exception => e
        puts "Error scanning device #{db_path}: #{e.message}"
        next
      end
    end
    puts "No valid devices found"
    nil
  end

  def valid_device_identifiers?(device_id, guid)
    puts "Validating identifiers - Device ID: #{device_id}, GUID: #{guid}"
    # Verify device_id is a valid 32-byte hex
    return false unless device_id&.match?(/\A[0-9a-f]{64}\z/)
    # Verify GUID is a valid UUID
    return false unless guid&.match?(/\A[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\z/)
    true
  end

  def ensure_device_directory
    device_dir = Rails.root.join('db', 'devices')
    FileUtils.mkdir_p(device_dir) unless Dir.exist?(device_dir)
  end

  def confirm_device(device_path)
    puts "========== CONFIRMING DEVICE =========="
    puts "Device path: #{device_path}"
    puts "Current session: #{session.to_h}"
    
    if device_path && valid_device?(device_path)
      puts "Device valid, updating session"
      session[:device_path] = device_path
      session[:pending_device_path] = nil
      puts "Updated session: #{session.to_h}"
    else
      puts "Device validation failed"
    end
  end

  def revoke_device
    puts "========== REVOKING DEVICE =========="
    puts "Before - Session: #{session.to_h}"
    session[:device_path] = nil
    session[:pending_device_path] = nil
    @current_device = nil
    puts "After - Session: #{session.to_h}"
  end

  def valid_device?(device_path)
    puts "========== VALIDATING DEVICE =========="
    puts "Device path: #{device_path}"
    return false unless device_path

    full_path = Rails.root.join('db', device_path)
    return false unless File.exist?(full_path)

    begin
      db = SQLite3::Database.new(full_path)
      info = db.get_first_row("SELECT device_id, guid, last_verified_at FROM device_info LIMIT 1")
      db.close

      puts "Device info: #{info.inspect}"
      if info && info[0] && info[1] && info[2] && valid_device_identifiers?(info[0], info[1])
        last_verified = Time.parse(info[2])
        result = Time.current - last_verified < 30.days
        puts "Validation result: #{result}"
        return result
      end
    rescue SQLite3::Exception => e
      puts "Error validating device: #{e.message}"
    end

    puts "Validation failed"
    false
  end

  def update_device_sync_state(device_path, status)
    return unless device_path
    
    full_path = Rails.root.join('db', device_path)
    return unless File.exist?(full_path)

    begin
      db = SQLite3::Database.new(full_path)
      db.execute(
        "INSERT INTO sync_state (last_sync, status) VALUES (?, ?)",
        [Time.current.iso8601, status]
      )
      db.close
    rescue SQLite3::Exception => e
      puts "Error updating sync state: #{e.message}"
    end
  end

  def ensure_authenticated
    puts "========== ENSURE AUTHENTICATED =========="
    puts "Session: #{session.to_h}"
    puts "Current Device: #{current_device.inspect}"
    
    unless current_device && valid_device?(session[:device_path])
      puts "Authentication failed"
      revoke_device
      redirect_to root_path
    else
      puts "Authentication successful"
    end
  end

  helper_method :current_device
end
