module Api
  module V1
    class AuthController < ApplicationController
      skip_before_action :verify_authenticity_token

      # Public API endpoints
def check_device
  logger.debug "========== CHECK DEVICE START =========="
  
  begin
    ensure_device_directory
    device_key = request.headers['HTTP_X_DEVICE_KEY']
    logger.debug "Received Device Key: #{device_key.inspect}"
    
    # First try to find matching device by key
    matching_device = find_device_by_key(device_key)
    
    if matching_device
      if matching_device[:info][:guid] && matching_device[:info][:handle]
        cleanup_duplicate_devices
      end
      
      if matching_device[:info][:handle]
        if recently_verified?(matching_device[:info][:last_verified_at])
          # Auto login for recently verified devices
          logger.debug "Device recently verified, confirming"
          confirm_device(matching_device[:path])
          render json: {
            status: 'authenticated',
            redirect_to: '/dashboard',
            device_key: matching_device[:info][:device_id],
            handle: matching_device[:info][:handle],  # Added
            phone: mask_phone(matching_device[:info][:phone]),  # Added
            device_path: matching_device[:path]  # Added to maintain consistency
          }
        else
          # Need quick verification
          logger.debug "Device needs verification"
          session[:pending_device_path] = matching_device[:path]
          send_verification(matching_device[:info][:phone])
          
          render json: {
            status: 'needs_quick_verification',
            handle: matching_device[:info][:handle],
            device_key: matching_device[:info][:device_id],
            masked_phone: mask_phone(matching_device[:info][:phone]),
            device_path: matching_device[:path]  # Added to maintain consistency
          }
        end
      else
        handle_unverified_device(matching_device)
      end
    else
      if device_key&.match?(/\A[0-9a-f]{64}\z/)
        create_new_device(device_key)
      else
        logger.debug "Invalid device key format or no key provided"
        create_new_device
      end
    end
    
  rescue SQLite3::Exception => e
    logger.error "Database error in check_device: #{e.message}\n#{e.backtrace.join("\n")}"
    render json: { error: 'Database error', details: e.message }, status: :internal_server_error
  rescue StandardError => e
    logger.error "Device check error: #{e.class} - #{e.message}\n#{e.backtrace.join("\n")}"
    render json: { error: 'Internal server error', details: e.message }, status: :internal_server_error
  end
end

      def verify_login
        logger.debug "========== VERIFY LOGIN START =========="
        
        # Get identifier from params, handling both direct and nested cases
        identifier = if params[:identifier]
          params[:identifier].strip
        elsif params.dig(:auth, :identifier)
          params.dig(:auth, :identifier).strip
        else
          logger.error "No identifier found in params: #{params.inspect}"
          return render json: { error: 'No identifier provided' }, status: :unprocessable_entity
        end

        logger.debug "Identifier: #{identifier}"
        logger.debug "Current session: #{session.to_h}"
        
        session.delete(:verification_phone)
        
        if identifier.start_with?('@')
          handle_guid_flow(identifier)
        else
          begin
            normalized_phone = normalize_phone(identifier)
            session[:verification_phone] = normalized_phone
            handle_phone_flow(normalized_phone)
          rescue StandardError => e
            logger.error "Verification error: #{e.message}"
            render json: { error: e.message }, status: :unprocessable_entity
          end
        end
      end

      def verify_code
        logger.debug "========== VERIFY CODE START =========="
        logger.debug "Parameters: #{params.inspect}"
        logger.debug "Session before: #{session.to_h}"
        
        device_path = session[:pending_device_path]
        unless device_path
          logger.error "No pending device path found"
          return render json: { error: 'Invalid session' }, status: :unprocessable_entity
        end

        code = params[:code].strip
        phone = session[:verification_phone] || params[:phone]
        cache_key = "verification:#{phone}"
        
        logger.debug "Code: #{code}"
        logger.debug "Phone: #{phone}"
        logger.debug "Device Path: #{device_path}"
        logger.debug "Cache key: #{cache_key}"
        
        verification = Rails.cache.read(cache_key)
        logger.debug "Cache data: #{verification.inspect}"

        if verification.nil?
          logger.error "No verification found in cache for key: #{cache_key}"
          return render json: { error: 'Verification code expired' }, status: :unprocessable_entity
        end

        if verification[:code].to_s == code.to_s
          logger.debug "Code verified successfully"
          db = SQLite3::Database.new(Rails.root.join('db', device_path))
          device_info = db.get_first_row("SELECT device_id, handle, guid, phone FROM device_info LIMIT 1")
          logger.debug "Device info: #{device_info.inspect}"

          if device_info && device_info[1] # Quick verification for known device
            logger.debug "Known device - updating verification"
            update_device_verification(db, device_info[1])
            confirm_device(device_path)
            db.close
            
            return render json: {
              status: 'authenticated',
              redirect_to: '/dashboard',
              device_key: device_info[0]
            }
          end
          db.close
          
          user = User.find_by(phone: phone)
          if user
            logger.debug "Existing user found: #{user.inspect}"
            link_device_to_user(user, device_path)
            confirm_device(device_path)
            
            db = SQLite3::Database.new(Rails.root.join('db', device_path))
            device_info = db.get_first_row("SELECT device_id FROM device_info LIMIT 1")
            db.close
            
            render json: {
              status: 'authenticated',
              redirect_to: '/dashboard',
              device_key: device_info[0]
            }
          else
            logger.debug "New user - needs handle creation"
            session[:pending_device_path] = device_path
            session[:verification_phone] = phone
            
            db = SQLite3::Database.new(Rails.root.join('db', device_path))
            device_info = db.get_first_row("SELECT device_id FROM device_info LIMIT 1")
            db.close
            
            render json: {
              status: 'needs_handle',
              phone: phone,
              device_key: device_info[0]
            }
          end
        else
          logger.debug "Code verification failed"
          logger.debug "Expected: #{verification[:code]}"
          logger.debug "Received: #{code}"
          render json: { error: 'Invalid code' }, status: :unprocessable_entity
        end
      end

def create_handle
  logger.debug "========== CREATE HANDLE =========="

  unless session[:pending_device_path] && session[:verification_phone]
    logger.error "Invalid session - path: #{session[:pending_device_path]}, phone: #{session[:verification_phone]}"
    return render json: { error: 'Invalid session' }, status: :unprocessable_entity
  end

  # Get handle but DON'T remove the @ symbol
  handle = (params[:handle] || params.dig(:auth, :handle)).to_s.strip
  phone = session[:verification_phone]

  # Update validation to expect @ at start
  unless handle.match?(/\A@[a-zA-Z0-9_]{1,29}\z/)
    logger.error "Invalid handle format: #{handle}"
    return render json: { error: 'Handle must start with @ and contain only letters, numbers, and underscores' }, status: :unprocessable_entity
  end

  # Check if handle is taken (keep the @ in the check)
  if User.exists?(handle: handle)
    logger.error "Handle already taken: #{handle}"
    return render json: { error: 'Handle already taken' }, status: :unprocessable_entity
  end

  # Create or update user (store with @)
  user = User.find_or_initialize_by(phone: phone)
  user.handle = handle
  user.guid ||= SecureRandom.uuid

  if user.save
    link_device_to_user(user, session[:pending_device_path])
    device_key = get_device_info(Rails.root.join('db', session[:pending_device_path]))[:device_id]

    logger.debug "Handle created successfully: #{handle} for phone: #{phone}"
    render json: {
      status: 'authenticated',
      redirect_to: '/dashboard',
      device_key: device_key
    }
  else
    logger.error "Failed to create handle: #{user.errors.full_messages.join(', ')}"
    render json: { error: 'Failed to create handle' }, status: :unprocessable_entity
  end
rescue StandardError => e
  logger.error "Handle creation error: #{e.class} - #{e.message}\n#{e.backtrace.join("\n")}"
  render json: { error: 'Internal server error' }, status: :internal_server_error
end

      def check_status
        logger.debug "========== CHECK STATUS =========="
        
        device_key = request.headers['HTTP_X_DEVICE_KEY']
        matching_device = find_device_by_key(device_key)
        
        if matching_device && matching_device[:info][:handle]
          render json: {
            status: 'authenticated',
            handle: matching_device[:info][:handle]
          }
        else
          render json: {
            status: 'unauthorized'
          }, status: :unauthorized
        end
      end

      private

      def find_device_by_key(device_key)
        return nil unless device_key&.match?(/\A[0-9a-f]{64}\z/)
        
        Dir.glob(Rails.root.join('db', 'devices', '*.sqlite3')).each do |db_path|
          begin
            logger.debug "Checking device database: #{db_path}"
            device_info = get_device_info(db_path)
            logger.debug "Device info found: #{device_info.inspect}"
            
            if device_info && device_info[:device_id] == device_key
              matching_device = {
                path: db_path.split('db/').last,
                info: device_info
              }
              logger.debug "Found matching device: #{matching_device.inspect}"
              return matching_device
            end
          rescue SQLite3::Exception => e
            logger.error "Error checking device #{db_path}: #{e.message}"
            next  # Skip this device if there's an error
          end
        end
        nil
      end

      def recently_verified?(last_verified_at)
        return false unless last_verified_at
        Time.parse(last_verified_at) > 30.days.ago
      end

      def handle_authenticated_device(device)
        logger.debug "Processing authenticated device: #{device.inspect}"
        db = SQLite3::Database.new(Rails.root.join('db', device[:path]))
        last_verified = db.get_first_row("SELECT last_verified_at FROM device_info LIMIT 1")[0]
        db.close
        
        if last_verified && Time.parse(last_verified) > 30.days.ago
          logger.debug "Device recently verified, confirming"
          confirm_device(device[:path])
          render json: {
            status: 'authenticated',
            redirect_to: '/dashboard',
            device_key: device[:info][:device_id]
          }
        else
          logger.debug "Device needs verification"
          session[:pending_device_path] = device[:path]
          session[:verification_phone] = device[:info][:phone]
          send_verification(device[:info][:phone])
          
          render json: {
            status: 'needs_quick_verification',
            database_path: device[:path],
            handle: device[:info][:handle],
            guid: device[:info][:guid],
            device_key: device[:info][:device_id],
            masked_phone: mask_phone(device[:info][:phone])
          }
        end
      end

      def handle_unverified_device(device)
        logger.debug "Processing unverified device: #{device.inspect}"
        
        # If device exists but registration isn't complete (no handle)
        # Just delete it and start fresh
        if device[:path] && File.exist?(Rails.root.join('db', device[:path]))
          begin
            logger.debug "Removing incomplete device: #{device[:path]}"
            File.delete(Rails.root.join('db', device[:path]))
          rescue StandardError => e
            logger.error "Error removing incomplete device: #{e.message}"
          end
        end

        # Create fresh device
        create_new_device(device[:info][:device_id])
      end

      def cleanup_duplicate_devices
        logger.debug "========== CLEANING UP DUPLICATE DEVICES =========="
        
        begin
          duplicates = {}
          devices_by_handle = {}
          
          # First pass: Collect all devices
          Dir.glob(Rails.root.join('db', 'devices', '*.sqlite3')).each do |db_path|
            begin
              device_info = get_device_info(db_path)
              next unless device_info
              
              # Group by device_id + guid for exact duplicates
              if device_info[:device_id] && device_info[:guid]
                key = "#{device_info[:device_id]}_#{device_info[:guid]}"
                logger.debug "Processing device with key: #{key}"
                
                duplicates[key] ||= []
                duplicates[key] << {
                  path: db_path,
                  info: device_info,
                  last_verified: Time.parse(device_info[:last_verified_at] || "2000-01-01")
                }
              end
              
              # Group by handle for verifying user associations
              if device_info[:handle]
                devices_by_handle[device_info[:handle]] ||= []
                devices_by_handle[device_info[:handle]] << {
                  path: db_path,
                  info: device_info,
                  last_verified: device_info[:last_verified_at]
                }
              end
            rescue StandardError => e
              logger.error "Error reading device #{db_path}: #{e.message}"
              next # Skip this device if there's an error
            end
          end
          
          # Second pass: Clean up exact duplicates
          duplicates.each do |key, devices|
            begin
              next if devices.length <= 1
              logger.debug "Found #{devices.length} duplicates for key: #{key}"
              
              # Keep the most recently verified device
              keep = devices.max_by { |d| d[:last_verified] }
              logger.debug "Keeping device: #{keep[:path]}"
              
              # Remove others
              devices.each do |device|
                begin
                  next if device[:path] == keep[:path]
                  next if device[:path] == session[:device_path] || 
                          device[:path] == session[:pending_device_path]
                  
                  logger.debug "Removing duplicate: #{device[:path]}"
                  File.delete(device[:path]) if File.exist?(device[:path])
                rescue StandardError => e
                  logger.error "Error removing duplicate #{device[:path]}: #{e.message}"
                  next # Continue with next device if deletion fails
                end
              end
            rescue StandardError => e
              logger.error "Error processing duplicate set for #{key}: #{e.message}"
              next # Skip this set if there's an error
            end
          end
          
# Third pass: Update user associations
          devices_by_handle.each do |handle, devices|
            begin
              next if devices.length <= 1
              
              user = User.find_by(handle: handle)
              next unless user
              
              devices.each do |device|
                begin
                  db = SQLite3::Database.new(Rails.root.join('db', device[:path]))
                  # Update GUID only if it doesn't match
                  db.execute(
                    "UPDATE device_info SET guid = ? WHERE handle = ? AND guid != ?",
                    [user.guid, handle, user.guid]
                  )
                  db.close
                rescue SQLite3::Exception => e
                  logger.error "Database error updating device #{device[:path]}: #{e.message}"
                  next # Skip this device if update fails
                rescue StandardError => e
                  logger.error "Error updating device #{device[:path]}: #{e.message}"
                  next
                end
              end
            rescue StandardError => e
              logger.error "Error processing handle #{handle}: #{e.message}"
              next # Skip this handle if there's an error
            end
          end
          
        rescue StandardError => e
          logger.error "Major error in cleanup_duplicate_devices: #{e.class} - #{e.message}\n#{e.backtrace.join("\n")}"
          # Don't fail the whole request if cleanup fails
          return
        end
        
        logger.debug "Cleanup completed successfully"
      end

      def create_new_device(device_key = nil)
        logger.debug "========== CREATE NEW DEVICE =========="
        
        begin
          device_id = device_key || SecureRandom.hex(32)
          device_guid = SecureRandom.uuid
          new_path = "devices/#{device_guid}.sqlite3"
          full_path = Rails.root.join('db', new_path)
          
          logger.debug "Creating new device:"
          logger.debug "Device ID: #{device_id}"
          logger.debug "GUID: #{device_guid}"
          logger.debug "Path: #{new_path}"
          
          # Make sure directory exists
          FileUtils.mkdir_p(File.dirname(full_path))
          
          # Check if we can write to the directory
          unless File.writable?(File.dirname(full_path))
            logger.error "Directory not writable: #{File.dirname(full_path)}"
            return render json: { error: 'Device storage not accessible' }, status: :internal_server_error
          end
          
          # Initialize database with transaction
          db = SQLite3::Database.new(full_path)
          db.transaction do
            db.execute "DROP TABLE IF EXISTS device_info"
            db.execute "DROP TABLE IF EXISTS sync_state"
            
            db.execute <<-SQL
              CREATE TABLE device_info (
                device_id TEXT PRIMARY KEY,
                handle TEXT,
                guid TEXT,
                phone TEXT,
                created_at TEXT,
                last_verified_at TEXT
              )
            SQL

            db.execute <<-SQL
              CREATE TABLE sync_state (
                id INTEGER PRIMARY KEY,
                last_sync TEXT,
                status TEXT
              )
            SQL
            
            db.execute(
              "INSERT INTO device_info (device_id, guid, created_at) VALUES (?, ?, ?)",
              [device_id, device_guid, Time.current.iso8601]
            )
            
            db.execute(
              "INSERT INTO sync_state (last_sync, status) VALUES (?, ?)",
              [Time.current.iso8601, 'initialized']
            )
          end
          db.close
          
          session[:pending_device_path] = new_path
          logger.debug "Device database initialized successfully"
          
          render json: {
            status: 'new_device',
            database_path: new_path,
            guid: device_guid,
            device_key: device_id
          }
          
        rescue SQLite3::Exception => e
          logger.error "Database error creating device: #{e.class} - #{e.message}\n#{e.backtrace.join("\n")}"
          render json: { error: 'Failed to create device database' }, status: :internal_server_error
        rescue StandardError => e
          logger.error "Error creating device: #{e.class} - #{e.message}\n#{e.backtrace.join("\n")}"
          render json: { error: 'Failed to create device' }, status: :internal_server_error
        end
      end

      def handle_guid_flow(handle)
        logger.debug "========== HANDLE GUID FLOW =========="
        handle = handle.delete('@')
        
        user = User.find_by(handle: handle)
        
        if user
          logger.debug "Found user: #{user.inspect}"
          session[:verification_phone] = user.phone
          send_verification(user.phone)
          
          render json: {
            status: 'verification_needed',
            handle: "@#{handle}",
            masked_phone: mask_phone(user.phone),
            message: "Welcome back @#{handle}!"
          }
        else
          render json: {
            status: 'handle_not_found',
            error: 'This username is not registered. Please register with your phone number.',
            suggestion: 'register_with_phone'
          }, status: :not_found
        end
      end

      def handle_phone_flow(phone)
        logger.debug "========== HANDLE PHONE FLOW =========="
        logger.debug "Phone: #{phone}"
        
        user = User.find_by(phone: phone)
        logger.debug "Existing user check: #{user.inspect}"
        
        send_verification(phone)
        
        if user
          logger.debug "Known user - sending verification"
          render json: {
            status: 'verification_needed',
            phone: phone,
            handle: user.handle
          }
        else
          logger.debug "New user - sending verification"
          render json: {
            status: 'verification_needed',
            phone: phone
          }
        end
      end

      def get_device_info(path)
        logger.debug "Getting device info from: #{path}"
        
        db = SQLite3::Database.new(path)
        result = db.get_first_row("SELECT device_id, handle, guid, phone FROM device_info LIMIT 1")
        db.close
        
        device_info = result ? {
          device_id: result[0],
          handle: result[1],
          guid: result[2],
          phone: result[3]
        } : nil
        
        logger.debug "Device info result: #{device_info.inspect}"
        device_info
      rescue SQLite3::Exception => e
        logger.error "Database error: #{e.message}"
        nil
      end

      def initialize_device_database(path, device_id)
        logger.debug "========== INITIALIZE DEVICE DB =========="
        logger.debug "Path: #{path}"
        logger.debug "Device ID: #{device_id}"
        
        # Extract GUID from path
        guid = path.split('/').last.gsub('.sqlite3', '')
        logger.debug "Using GUID: #{guid}"
        
        FileUtils.mkdir_p(File.dirname(path))
        
        db = SQLite3::Database.new(path)
        db.transaction do
          db.execute "DROP TABLE IF EXISTS device_info"
          db.execute "DROP TABLE IF EXISTS sync_state"
          
          db.execute <<-SQL
            CREATE TABLE device_info (
              device_id TEXT PRIMARY KEY,
              handle TEXT,
              guid TEXT,
              phone TEXT,
              created_at TEXT,
              last_verified_at TEXT
            )
          SQL

          db.execute <<-SQL
            CREATE TABLE sync_state (
              id INTEGER PRIMARY KEY,
              last_sync TEXT,
              status TEXT
            )
          SQL
          
          # Updated to include GUID
          db.execute(
            "INSERT INTO device_info (device_id, guid, created_at) VALUES (?, ?, ?)",
            [device_id, guid, Time.current.iso8601]
          )
          
          db.execute(
            "INSERT INTO sync_state (last_sync, status) VALUES (?, ?)",
            [Time.current.iso8601, 'initialized']
          )
        end
        db.close
        logger.debug "Database initialized successfully"
      rescue SQLite3::Exception => e
        logger.error "Database initialization error: #{e.message}"
        raise e
      end

      def send_verification(phone)
        logger.debug "========== SEND VERIFICATION =========="
        code = rand(100000..999999).to_s
        cache_key = "verification:#{phone}"
        
        cache_data = {
          code: code,
          phone: phone,
          expires_at: 10.minutes.from_now
        }
        
        Rails.cache.write(
          cache_key, 
          cache_data,
          expires_in: 10.minutes,
          race_condition_ttl: 10.seconds,
          force: true  # Ensure we overwrite any existing code
        )
        
        # Verify the write succeeded
        stored_data = Rails.cache.read(cache_key)
        if stored_data.nil?
          logger.error "Failed to store verification code in cache"
          raise "Cache write failed"
        end
        
        logger.debug "Generated code: #{code}"
        logger.debug "Cache key: #{cache_key}"
        logger.debug "Cache data: #{cache_data.inspect}"
        logger.debug "Verification data in cache: #{stored_data.inspect}"
        
        TwilioService.send_sms(phone, "Your SuperApp verification code: #{code}")
        logger.debug "SMS sent successfully"
      end

      def normalize_phone(phone)
        logger.debug "Normalizing phone: #{phone}"
        phone = phone.gsub(/[^0-9+]/, '')
        
        case phone
        when /^\+44/
          unless phone.match?(/^\+44[7][0-9]{9}$/)
            error_msg = "Invalid UK mobile number format. Must start with +447"
            logger.error "Error: #{error_msg}"
            raise error_msg
          end
        when /^\+65/
          unless phone.match?(/^\+65[689][0-9]{7}$/)
            error_msg = "Invalid Singapore mobile number format"
            logger.error "Error: #{error_msg}"
            raise error_msg
          end
        else
          error_msg = "Invalid phone format. Please use +44 or +65"
          logger.error "Error: #{error_msg}"
          raise error_msg
        end
        
        logger.debug "Normalized phone: #{phone}"
        phone
      end

      def mask_phone(phone)
        return unless phone
        masked = "*******#{phone.last(4)}"
        logger.debug "Masked phone: #{masked}"
        masked
      end

      def confirm_device(device_path)
        logger.debug "========== CONFIRM DEVICE =========="
        logger.debug "Device path: #{device_path}"
        
        db = SQLite3::Database.new(Rails.root.join('db', device_path))
        db.execute(
          "UPDATE device_info SET last_verified_at = ?",
          [Time.current.iso8601]
        )
        db.close
        logger.debug "Device verification updated"
      end

      def update_device_verification(db, handle)
        logger.debug "========== UPDATE DEVICE VERIFICATION =========="
        logger.debug "Updating verification for handle: #{handle}"
        
        db.execute(
          "UPDATE device_info SET last_verified_at = ?",
          [Time.current.iso8601]
        )
        logger.debug "Device verification timestamp updated"
      end

      def link_device_to_user(user, device_path)
        logger.debug "========== LINK DEVICE TO USER =========="
        logger.debug "Linking device to user: #{user.inspect}"
        logger.debug "Device path: #{device_path}"
        
        db = SQLite3::Database.new(Rails.root.join('db', device_path))
        db.transaction do
          # Update device info with all user details
          db.execute(
            "UPDATE device_info SET handle = ?, phone = ?, guid = ?, last_verified_at = ?",
            [user.handle, user.phone, user.guid, Time.current.iso8601]
          )
          
          # Update sync state
          db.execute(
            "INSERT INTO sync_state (last_sync, status) VALUES (?, ?)",
            [Time.current.iso8601, 'linked_to_user']
          )
        end
        db.close
        
        # Set session path for authenticated device
        session[:device_path] = device_path
        session[:current_handle] = user.handle
        
        logger.debug "Device linked to user"
      end

      def ensure_device_directory
        logger.debug "========== ENSURE DEVICE DIRECTORY =========="
        device_dir = Rails.root.join('db', 'devices')
        
        unless Dir.exist?(device_dir)
          logger.debug "Creating devices directory: #{device_dir}"
          FileUtils.mkdir_p(device_dir)
        end
      end

      def persist_device_verification(device_path, handle)
        logger.debug "========== PERSIST DEVICE VERIFICATION =========="
        logger.debug "Persisting verification for device: #{device_path}"
        
        db = SQLite3::Database.new(Rails.root.join('db', device_path))
        db.transaction do
          db.execute(
            "UPDATE device_info SET last_verified_at = ? WHERE handle = ?",
            [Time.current.iso8601, handle]
          )
          
          db.execute(
            "UPDATE sync_state SET last_sync = ?, status = ?",
            [Time.current.iso8601, 'verified']
          )
        end
        db.close
        logger.debug "Device verification persisted"
      rescue SQLite3::Exception => e
        logger.error "Database error while persisting verification: #{e.message}"
        raise e
      end

      def verify_device_status(device_path)
        logger.debug "========== VERIFY DEVICE STATUS =========="
        
        db = SQLite3::Database.new(Rails.root.join('db', device_path))
        result = db.get_first_row(<<-SQL
          SELECT 
            device_info.last_verified_at,
            sync_state.status,
            sync_state.last_sync
          FROM device_info
          JOIN sync_state ON 1=1
          LIMIT 1
        SQL
        )
        db.close
        
        {
          last_verified_at: result[0],
          sync_status: result[1],
          last_sync: result[2]
        }
      rescue SQLite3::Exception => e
        logger.error "Database error while checking device status: #{e.message}"
        nil
      end

    end
  end
end
