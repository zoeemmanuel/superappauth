class DashboardController < ApplicationController
  before_action :ensure_authenticated
  
  def index
    puts "========== DASHBOARD INDEX =========="
    puts "Session: #{session.to_h}"
    puts "Current Device Info: #{current_device.inspect}"
    
    @device_info = current_device
    if @device_info
      puts "Device found - rendering dashboard"
    else
      puts "No device info - redirecting"
      redirect_to root_path
    end
  end

  def logout
    puts "========== LOGOUT =========="
    puts "Before - Session: #{session.to_h}"
    puts "Current Device: #{current_device.inspect}"
    
    if current_device
      device_path = session[:device_path] || session[:pending_device_path]
      puts "Device path before logout: #{device_path}"
      
      reset_session
      revoke_device
      
      puts "After - Session: #{session.to_h}"
      redirect_to root_path
    else
      redirect_to root_path
    end
  end

  def reset_devices
    puts "========== RESET DEVICES =========="
    user = User.find_by(handle: current_device[:handle])
    puts "Current user: #{user.inspect}"
    
    if user
      Dir.glob(Rails.root.join('db', 'devices', '*.sqlite3')).each do |db_path|
        begin
          puts "Checking device: #{db_path}"
          db = SQLite3::Database.new(db_path)
          device_info = db.get_first_row("SELECT handle, guid FROM device_info WHERE handle = ? AND guid = ?", 
                                       [user.handle, user.guid])
          db.close
          
          if device_info
            puts "Deleting device database: #{db_path}"
            File.delete(db_path)
          end
        rescue SQLite3::Exception => e
          puts "Error checking device database: #{e.message}"
        end
      end
    end
    
    revoke_device
    redirect_to root_path
  end

  def update_handle
    puts "========== UPDATE HANDLE =========="
    new_handle = params[:handle].strip
    puts "New handle requested: #{new_handle}"
    
    unless new_handle.start_with?('@')
      return render json: { error: 'Handle must start with @' }, status: :unprocessable_entity
    end

    user = User.find_by(handle: current_device[:handle])
    puts "Current user: #{user.inspect}"
    return render json: { error: 'User not found' }, status: :not_found unless user

    if User.where(handle: new_handle).where.not(id: user.id).exists?
      return render json: { error: 'Handle already taken' }, status: :unprocessable_entity
    end

    ActiveRecord::Base.transaction do
      user.update!(handle: new_handle)
      puts "User updated with new handle"

      Dir.glob(Rails.root.join('db', 'devices', '*.sqlite3')).each do |db_path|
        begin
          puts "Updating device: #{db_path}"
          db = SQLite3::Database.new(db_path)
          db.execute(
            "UPDATE device_info SET handle = ? WHERE handle = ? AND guid = ?",
            [new_handle, user.handle, user.guid]
          )
          if db.changes > 0
            puts "Device updated, updating sync state"
            db.execute(
              "INSERT INTO sync_state (last_sync, status) VALUES (?, ?)",
              [Time.current.iso8601, 'handle_updated']
            )
          end
          db.close
        rescue SQLite3::Exception => e
          puts "Error updating device database: #{e.message}"
        end
      end

      render json: { 
        status: 'success',
        handle: new_handle
      }
    end
  rescue ActiveRecord::RecordInvalid => e
    puts "Handle update failed: #{e.message}"
    render json: { error: e.message }, status: :unprocessable_entity
  end

  private

  def ensure_authenticated
    puts "========== DASHBOARD AUTH CHECK =========="
    puts "Session: #{session.to_h}"
    puts "Current Device: #{current_device.inspect}"
    
    unless current_device
      puts "Authentication failed - no current device"
      revoke_device
      redirect_to root_path
    else
      puts "Authentication successful"
    end
  end
end
