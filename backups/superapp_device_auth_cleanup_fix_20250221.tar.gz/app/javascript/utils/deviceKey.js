const generateDeviceKey = async () => {
    try {
      // Generate random bytes
      const array = new Uint8Array(32);
      crypto.getRandomValues(array);
      
      // Convert to hex string
      const key = Array.from(array)
        .map(b => b.toString(16).padStart(2, '0'))
        .join('');
      
      return key;
    } catch (err) {
      console.error('Failed to generate device key:', err);
      return null;
    }
};

const getStoredDeviceKey = async () => {
    // First check sessionStorage (for performance)
    const sessionKey = sessionStorage.getItem('device_key');
    if (sessionKey) {
      console.log('Found key in session');
      return sessionKey;
    }
    // Then check SQLite databases via backend
    try {
      console.log('Checking for existing device...');
      
      // If we have a key in storage, include it in headers
      const currentKey = sessionStorage.getItem('device_key');
      const headers = {
        'Content-Type': 'application/json'
      };
      
      if (currentKey) {
        headers['X-Device-Key'] = currentKey;
      }
      const response = await fetch('/api/v1/auth/check_device', {
        method: 'POST',
        headers: headers
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      
      if (data.device_key) {
        console.log('Found existing device key');
        sessionStorage.setItem('device_key', data.device_key);
        return data.device_key;
      }
      
      // If no existing device, generate new key
      console.log('No existing device found, generating new key');
      const newKey = await generateDeviceKey();
      if (newKey) {
        sessionStorage.setItem('device_key', newKey);
      }
      return newKey;
    } catch (err) {
      console.error('Failed to get stored device key:', err);
      // On error, try to generate a new key instead of returning null
      const newKey = await generateDeviceKey();
      if (newKey) {
        sessionStorage.setItem('device_key', newKey);
        return newKey;
      }
      return null;
    }
};

const storeDeviceKey = (key) => {
    if (key) {
      sessionStorage.setItem('device_key', key);
      console.log('Stored device key:', key);
    }
};

module.exports = {
    generateDeviceKey,
    getStoredDeviceKey,
    storeDeviceKey
};
