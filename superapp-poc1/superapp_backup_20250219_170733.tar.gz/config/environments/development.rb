Rails.application.configure do
  # Development settings
  config.cache_classes = false
  config.eager_load = false
  config.consider_all_requests_local = true
  
  # Host configuration
  config.hosts.clear
  config.hosts << "superappproject.com"
  config.hosts << "www.superappproject.com"
  config.hosts << "localhost"
  config.hosts << "0.0.0.0"
  
  # Active Storage configuration
  config.active_storage.service = :local

  # Enable/disable caching. By default caching is disabled.
  if Rails.root.join("tmp/caching-dev.txt").exist?
    config.action_controller.perform_caching = true
    config.action_controller.enable_fragment_cache_logging = true
    config.cache_store = :memory_store
    config.public_file_server.headers = {
      "Cache-Control" => "public, max-age=#{2.days.to_i}"
    }
  else
    config.action_controller.perform_caching = false
    config.cache_store = :null_store
  end

  # Print deprecation notices to the Rails logger.
  config.active_support.deprecation = :log

  # Raise exceptions for disallowed deprecations.
  config.active_support.disallowed_deprecation = :raise

  # Tell Active Support which deprecation messages to disallow.
  config.active_support.disallowed_deprecation_warnings = []

  # Raise an error on page load if there are pending migrations.
  config.active_record.migration_error = :page_load

  # Highlight code that triggered database queries in logs.
  config.active_record.verbose_query_logs = true

  # CORS configuration
  config.middleware.insert_before 0, Rack::Cors do
    allow do
      origins 'superappproject.com', 'www.superappproject.com', 'localhost:3000'
      resource '*',
        headers: :any,
        methods: [:get, :post, :put, :patch, :delete, :options, :head],
        credentials: true
    end
  end
end
