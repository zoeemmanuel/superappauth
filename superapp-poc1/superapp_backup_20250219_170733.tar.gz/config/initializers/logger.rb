Rails.logger = Logger.new(STDOUT)
Rails.logger.level = Logger::INFO
