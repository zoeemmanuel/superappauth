module.exports = {
  content: [
    './app/views/**/*.{erb,html}',
    './app/javascript/**/*.{js,jsx}',
    './app/assets/builds/**/*.{js,jsx}'
  ],
  theme: {
    extend: {
      colors: {
        gray: {
          900: '#111827'
        },
        teal: {
          500: '#14b8a6',
          600: '#0d9488'
        }
      }
    },
  },
  plugins: [],
}
