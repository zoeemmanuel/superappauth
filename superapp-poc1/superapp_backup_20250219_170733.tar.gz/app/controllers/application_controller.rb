class ApplicationController < ActionController::Base
  protect_from_forgery with: :exception
  after_action :set_csrf_token_header

  private

  def set_csrf_token_header
    response.headers['X-CSRF-Token'] = form_authenticity_token
  end

  def current_device
    @current_device ||= begin
      device_path = session[:device_path] || session[:pending_device_path]
      return nil unless device_path

      full_path = Rails.root.join('db', device_path)
      Rails.logger.info "Checking device at: #{full_path}"

      if File.exist?(full_path)
        db = SQLite3::Database.new(full_path)
        # Get device info with focus on device_id and guid for security
        device_info = db.get_first_row("SELECT device_id, handle, guid, phone, last_verified_at FROM device_info LIMIT 1")
        if device_info && valid_device_identifiers?(device_info[0], device_info[2])
          sync_info = db.get_first_row("SELECT last_sync, status FROM sync_state ORDER BY id DESC LIMIT 1")
          db.close

          {
            device_id: device_info[0],
            handle: device_info[1],
            guid: device_info[2],
            phone: device_info[3],
            last_verified_at: device_info[4],
            sync_state: {
              last_sync: sync_info&.[](0),
              status: sync_info&.[](1)
            }
          }
        else
          db.close
          nil
        end
      end
    rescue SQLite3::Exception => e
      Rails.logger.error "Database error in current_device: #{e.message}"
      nil
    end
  end

  def valid_device_identifiers?(device_id, guid)
    # Verify device_id is a valid 32-byte hex
    return false unless device_id&.match?(/\A[0-9a-f]{64}\z/)
    # Verify GUID is a valid UUID
    return false unless guid&.match?(/\A[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\z/)
    true
  end

  def ensure_device_directory
    device_dir = Rails.root.join('db', 'devices')
    FileUtils.mkdir_p(device_dir) unless Dir.exist?(device_dir)
  end

  def confirm_device(device_path)
    if device_path && valid_device?(device_path)
      Rails.logger.info "Confirming device: #{device_path}"
      session[:device_path] = device_path
      session[:pending_device_path] = nil
    end
  end

  def revoke_device
    Rails.logger.info "Revoking device session"
    session[:device_path] = nil
    session[:pending_device_path] = nil
    @current_device = nil
  end

  def valid_device?(device_path)
    return false unless device_path

    full_path = Rails.root.join('db', device_path)
    return false unless File.exist?(full_path)

    begin
      db = SQLite3::Database.new(full_path)
      info = db.get_first_row("SELECT device_id, guid, last_verified_at FROM device_info LIMIT 1")
      db.close

      if info && info[0] && info[1] && info[2] && valid_device_identifiers?(info[0], info[1])
        last_verified = Time.parse(info[2])
        return Time.current - last_verified < 30.days
      end
    rescue SQLite3::Exception => e
      Rails.logger.error "Error validating device: #{e.message}"
    end

    false
  end

  def update_device_sync_state(device_path, status)
    return unless device_path
    
    full_path = Rails.root.join('db', device_path)
    return unless File.exist?(full_path)

    begin
      db = SQLite3::Database.new(full_path)
      db.execute(
        "INSERT INTO sync_state (last_sync, status) VALUES (?, ?)",
        [Time.current.iso8601, status]
      )
      db.close
    rescue SQLite3::Exception => e
      Rails.logger.error "Error updating sync state: #{e.message}"
    end
  end

  def ensure_authenticated
    unless current_device && valid_device?(session[:device_path])
      revoke_device
      redirect_to root_path
    end
  end

  helper_method :current_device
end
