module Api
  module V1
    class AuthController < ApplicationController
      skip_before_action :verify_authenticity_token

def check_device 
  ensure_device_directory
  
  Dir.glob(Rails.root.join('db', 'devices', '*.sqlite3')).each do |db_path|
    device_info = get_device_info(db_path)
    
    if device_info && device_info[:device_id] && device_info[:guid]
      relative_path = db_path.split('db/').last
      
      if device_info[:handle]
        db = SQLite3::Database.new(db_path)
        last_verified = db.get_first_row("SELECT last_verified_at FROM device_info LIMIT 1")[0]
        db.close

        if last_verified && Time.parse(last_verified) > 30.days.ago
          # Auto-login for recently verified devices
          confirm_device(relative_path)
          return render json: {
            status: 'authenticated',
            redirect_to: '/dashboard'
          }
        else
          # Known device but needs verification
          session[:pending_device_path] = relative_path
          session[:verification_phone] = device_info[:phone]
          send_verification(device_info[:phone])
          
          return render json: {
            status: 'needs_quick_verification',
            database_path: relative_path,
            handle: device_info[:handle],
            guid: device_info[:guid],  # Include GUID
            masked_phone: mask_phone(device_info[:phone])
          }
        end
      end
    end
  end
  
  create_new_device
end

      def verify_login
        Rails.logger.info "---------- VERIFY LOGIN START ----------"
        identifier = params[:identifier].strip
        
        # Clear any existing verification data
        session.delete(:verification_phone)
        
        if identifier.start_with?('@')
          handle_guid_flow(identifier)
        else
          begin
            normalized_phone = normalize_phone(identifier)
            session[:verification_phone] = normalized_phone
            handle_phone_flow(normalized_phone)
          rescue StandardError => e
            Rails.logger.error "Verification error: #{e.message}"
            render json: { error: e.message }, status: :unprocessable_entity
          end
        end
      end

      def verify_code
        Rails.logger.info "---------- VERIFY CODE START ----------"
        code = params[:code].strip
        phone = session[:verification_phone] || params[:phone]
        device_path = session[:pending_device_path]
        
        Rails.logger.info "Verifying code: #{code} for phone: #{phone}"
        Rails.logger.info "Device path from session: #{device_path}"
        
        cache_key = "verification:#{phone}"
        verification = Rails.cache.read(cache_key)
        Rails.logger.info "Cache key: #{cache_key}"
        Rails.logger.info "Verification data from cache: #{verification.inspect}"
        
        if verification && verification[:code] == code
          db = SQLite3::Database.new(Rails.root.join('db', device_path))
          device_info = db.get_first_row("SELECT handle, guid, phone FROM device_info LIMIT 1")
          
          if device_info && device_info[0] # Quick verification for known device
            update_device_verification(db, device_info[0])
            confirm_device(device_path)
            db.close
            
            return render json: {
              status: 'authenticated',
              redirect_to: '/dashboard'
            }
          end
          db.close
          
          user = User.find_by(phone: phone)
          if user
            link_device_to_user(user, device_path)
            confirm_device(device_path)
            
            render json: {
              status: 'authenticated',
              redirect_to: '/dashboard'
            }
          else
            render json: {
              status: 'needs_handle',
              phone: phone
            }
          end
        else
          Rails.logger.error "Invalid code comparison:"
          Rails.logger.error "Cache data: #{verification.inspect}"
          Rails.logger.error "Received code: #{code}"
          render json: { error: 'Invalid code' }, status: :unprocessable_entity
        end
        Rails.logger.info "---------- VERIFY CODE END ----------"
      end

      def create_handle
        handle = params[:handle].strip
        phone = params[:phone]
        device_path = session[:pending_device_path]

        ActiveRecord::Base.transaction do
          user = User.create!(
            handle: handle,
            phone: phone,
            guid: SecureRandom.uuid
          )

          link_device_to_user(user, device_path)
          confirm_device(device_path)
          Rails.logger.info "Created user and linked device: #{user.inspect}"

          render json: {
            status: 'success',
            redirect_to: '/dashboard'
          }
        end
      rescue ActiveRecord::RecordInvalid => e
        Rails.logger.error "Handle creation failed: #{e.message}"
        render json: { error: e.message }, status: :unprocessable_entity
      end

      def update_handle
        Rails.logger.info "---------- UPDATE HANDLE START ----------"
        new_handle = params[:handle].strip
        
        unless new_handle.start_with?('@')
          return render json: { error: 'Handle must start with @' }, status: :unprocessable_entity
        end

        ActiveRecord::Base.transaction do
          device_path = session[:device_path]
          return render json: { error: 'No device found' }, status: :not_found unless device_path

          db = SQLite3::Database.new(Rails.root.join('db', device_path))
          device_info = db.get_first_row("SELECT handle, guid FROM device_info LIMIT 1")
          
          return render json: { error: 'Device not linked to user' }, status: :unprocessable_entity unless device_info

          old_handle = device_info[0]
          user_guid = device_info[1]

          # Update user record
          user = User.find_by(guid: user_guid)
          return render json: { error: 'User not found' }, status: :not_found unless user

          # Check if new handle is taken
          if User.where(handle: new_handle).where.not(guid: user_guid).exists?
            db.close
            return render json: { error: 'Handle already taken' }, status: :unprocessable_entity
          end

          # Update user record
          user.update!(handle: new_handle)

          # Update all device databases for this user
          Dir.glob(Rails.root.join('db', 'devices', '*.sqlite3')).each do |device_db_path|
            begin
              device_db = SQLite3::Database.new(device_db_path)
              device_db.execute(
                "UPDATE device_info SET handle = ? WHERE guid = ?",
                [new_handle, user_guid]
              )
              device_db.execute(
                "INSERT INTO sync_state (last_sync, status) VALUES (?, ?)",
                [Time.current.iso8601, 'handle_updated']
              )
              device_db.close
            rescue SQLite3::Exception => e
              Rails.logger.error "Error updating device database: #{e.message}"
            end
          end

          Rails.logger.info "Handle updated from #{old_handle} to #{new_handle}"
          render json: { 
            status: 'success',
            handle: new_handle
          }
        end
      rescue ActiveRecord::RecordInvalid => e
        Rails.logger.error "Handle update failed: #{e.message}"
        render json: { error: e.message }, status: :unprocessable_entity
      rescue SQLite3::Exception => e
        Rails.logger.error "Database error: #{e.message}"
        render json: { error: 'Database error occurred' }, status: :internal_server_error
      end

      private

      def create_new_device
        device_id = SecureRandom.hex(32)  # Cryptographically secure device ID per spec
        device_guid = SecureRandom.uuid    # Unique device GUID per spec
        new_path = "devices/#{device_guid}.sqlite3"
        full_path = Rails.root.join('db', new_path)
        
        initialize_device_database(full_path, device_id)
        session[:pending_device_path] = new_path
        
        render json: {
          status: 'new_device',
          database_path: new_path
        }
      end

      def get_device_info(path)
        db = SQLite3::Database.new(path)
        result = db.get_first_row("SELECT device_id, handle, guid, phone FROM device_info LIMIT 1")
        db.close
        
        result ? {
          device_id: result[0],
          handle: result[1],
          guid: result[2],
          phone: result[3]
        } : nil
      rescue SQLite3::Exception => e
        Rails.logger.error "Database error: #{e.message}"
        nil
      end

      def initialize_device_database(path, device_id)
        FileUtils.mkdir_p(File.dirname(path))
        
        db = SQLite3::Database.new(path)
        db.transaction do
          # Drop tables first to ensure clean state
          db.execute "DROP TABLE IF EXISTS device_info"
          db.execute "DROP TABLE IF EXISTS sync_state"
          
          # Create tables
          db.execute <<-SQL
            CREATE TABLE device_info (
              device_id TEXT PRIMARY KEY,
              handle TEXT,
              guid TEXT,
              phone TEXT,
              created_at TEXT,
              last_verified_at TEXT
            )
          SQL

          db.execute <<-SQL
            CREATE TABLE sync_state (
              id INTEGER PRIMARY KEY,
              last_sync TEXT,
              status TEXT
            )
          SQL
          
          db.execute(
            "INSERT INTO device_info (device_id, created_at) VALUES (?, ?)",
            [device_id, Time.current.iso8601]
          )
          
          db.execute(
            "INSERT INTO sync_state (last_sync, status) VALUES (?, ?)",
            [Time.current.iso8601, 'initialized']
          )
        end
        db.close
      rescue SQLite3::Exception => e
        Rails.logger.error "Database initialization error: #{e.message}"
        raise e
      end

      def update_device_verification(db, handle)
        now = Time.current.iso8601
        db.transaction do
          db.execute(
            "UPDATE device_info SET last_verified_at = ? WHERE handle = ?",
            [now, handle]
          )
          db.execute(
            "UPDATE sync_state SET last_sync = ?, status = ?",
            [now, 'verified']
          )
        end
      end

      def link_device_to_user(user, device_path)
        return unless device_path
        
        full_path = Rails.root.join('db', device_path)
        return unless File.exist?(full_path)
        
        Rails.logger.info "Linking device #{device_path} to user #{user.handle}"
        
        db = SQLite3::Database.new(full_path)
        db.transaction do
          db.execute(
            "UPDATE device_info SET handle = ?, guid = ?, phone = ?, last_verified_at = ?",
            [user.handle, user.guid, user.phone, Time.current.iso8601]
          )
          db.execute(
            "UPDATE sync_state SET last_sync = ?, status = ?",
            [Time.current.iso8601, 'linked']
          )
        end
        db.close
      end

      def handle_guid_flow(handle)
        user = User.find_by(handle: handle)
        if user
          session[:verification_phone] = user.phone
          send_verification(user.phone)
          render json: {
            status: 'verification_sent',
            handle: user.handle,
            masked_phone: mask_phone(user.phone)
          }
        else
          render json: { error: 'Handle not found' }, status: :not_found
        end
      end

      def handle_phone_flow(phone)
        user = User.find_by(phone: phone)
        send_verification(phone)
        
        if user
          render json: {
            status: 'verification_sent',
            handle: user.handle,
            masked_phone: mask_phone(phone)
          }
        else
          render json: {
            status: 'verification_sent',
            masked_phone: mask_phone(phone)
          }
        end
      end

      def send_verification(phone)
        Rails.logger.info "---------- SEND VERIFICATION START ----------"
        code = rand(100000..999999).to_s
        cache_key = "verification:#{phone}"
        
        cache_data = {
          code: code,
          phone: phone,
          expires_at: 10.minutes.from_now
        }
        
        Rails.logger.info "Generated code: #{code} for phone: #{phone}"
        Rails.logger.info "Writing to cache key: #{cache_key}"
        Rails.logger.info "Cache data: #{cache_data.inspect}"
        
        Rails.cache.write(cache_key, cache_data, expires_in: 10.minutes)
        
        # Verify cache write
        stored_data = Rails.cache.read(cache_key)
        Rails.logger.info "Verification from cache: #{stored_data.inspect}"
        
        TwilioService.send_sms(phone, "Your SuperApp verification code: #{code}")
        Rails.logger.info "---------- SEND VERIFICATION END ----------"
      end

      def normalize_phone(phone)
        phone = phone.gsub(/[^0-9+]/, '')
        unless phone.match?(/^\+(?:44|65)\d{10}$/)
          raise "Invalid phone format. Please use +44 or +65"
        end
        phone
      end

      def mask_phone(phone)
        return unless phone
        "*******#{phone.last(4)}"
      end
    end
  end
end
