class DashboardController < ApplicationController
  before_action :ensure_authenticated
  
  def index
    @device_info = current_device
    return redirect_to root_path unless @device_info
  end

  def logout
    revoke_device  # Use the proper revoke method
    redirect_to root_path
  end

  def reset_devices
    user = User.find_by(handle: current_device[:handle])
    if user
      # Delete all device databases for this user
      Dir.glob(Rails.root.join('db', 'devices', '*.sqlite3')).each do |db_path|
        begin
          db = SQLite3::Database.new(db_path)
          device_info = db.get_first_row("SELECT handle, guid FROM device_info WHERE handle = ? AND guid = ?", 
                                       [user.handle, user.guid])
          db.close
          # Only delete if both handle and guid match
          File.delete(db_path) if device_info
        rescue SQLite3::Exception => e
          Rails.logger.error "Error checking device database: #{e.message}"
        end
      end
    end
    
    revoke_device  # Use the proper revoke method
    redirect_to root_path
  end

  def update_handle
    new_handle = params[:handle].strip
    
    unless new_handle.start_with?('@')
      return render json: { error: 'Handle must start with @' }, status: :unprocessable_entity
    end

    user = User.find_by(handle: current_device[:handle])
    return render json: { error: 'User not found' }, status: :not_found unless user

    # Check if new handle is taken
    if User.where(handle: new_handle).where.not(id: user.id).exists?
      return render json: { error: 'Handle already taken' }, status: :unprocessable_entity
    end

    ActiveRecord::Base.transaction do
      # Update user record
      user.update!(handle: new_handle)

      # Update all device databases for this user
      Dir.glob(Rails.root.join('db', 'devices', '*.sqlite3')).each do |db_path|
        begin
          db = SQLite3::Database.new(db_path)
          # Update only if device belongs to this user (check both handle and guid)
          db.execute(
            "UPDATE device_info SET handle = ? WHERE handle = ? AND guid = ?",
            [new_handle, user.handle, user.guid]
          )
          if db.changes > 0  # Only update sync state if device was updated
            db.execute(
              "INSERT INTO sync_state (last_sync, status) VALUES (?, ?)",
              [Time.current.iso8601, 'handle_updated']
            )
          end
          db.close
        rescue SQLite3::Exception => e
          Rails.logger.error "Error updating device database: #{e.message}"
        end
      end

      render json: { 
        status: 'success',
        handle: new_handle
      }
    end
  rescue ActiveRecord::RecordInvalid => e
    render json: { error: e.message }, status: :unprocessable_entity
  end

  private

  def ensure_authenticated
    unless current_device
      revoke_device  # Use the proper revoke method
      redirect_to root_path
    end
  end
end
