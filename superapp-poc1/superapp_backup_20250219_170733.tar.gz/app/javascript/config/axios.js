import axios from 'axios';

const instance = axios.create({
  headers: {
    'X-CSRF-Token': window.csrfToken,
    'Content-Type': 'application/json',
    'Accept': 'application/json'
  }
});

export default instance;
