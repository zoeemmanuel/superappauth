import React, { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import axios from '../../config/axios';

const UnifiedLogin = () => {
  const [step, setStep] = useState('checking');
  const [identifier, setIdentifier] = useState('');
  const [verificationCode, setVerificationCode] = useState('');
  const [handle, setHandle] = useState('');
  const [error, setError] = useState('');
  const [phone, setPhone] = useState('');
  const [isQuickVerification, setIsQuickVerification] = useState(false);

  useEffect(() => {
    checkDevice();
  }, []);

  const checkDevice = async () => {
    try {
      // Let backend scan for matching device database
      const response = await axios.post('/api/v1/auth/check_device', {});

      if (response.data.status === 'authenticated') {
        window.location.href = response.data.redirect_to;
      } else if (response.data.status === 'needs_quick_verification') {
        setHandle(response.data.handle);
        setPhone(response.data.masked_phone);
        setIsQuickVerification(true);
        setStep('verify');
      } else {
        setStep('initial');
      }
    } catch (err) {
      console.error('Device check failed:', err);
      setError('Device check failed');
      setStep('initial');
    }
  };

  const handleSubmit = async () => {
    setError('');
    
    try {
      const response = await axios.post('/api/v1/auth/verify_login', {
        identifier
      });

      if (response.data.status === 'verification_sent') {
        setHandle(response.data.handle || '');
        setPhone(response.data.masked_phone);
        setStep('verify');
      }
    } catch (err) {
      setError(err.response?.data?.error || 'Verification failed');
    }
  };

  const handleVerificationSubmit = async () => {
    if (verificationCode.length !== 6) return;

    try {
      const response = await axios.post('/api/v1/auth/verify_code', {
        code: verificationCode,
        phone: identifier || phone
      });

      if (response.data.status === 'authenticated') {
        window.location.href = response.data.redirect_to;
      } else if (response.data.status === 'needs_handle') {
        setStep('create_handle');
      }
    } catch (err) {
      setError(err.response?.data?.error || 'Invalid verification code');
      setVerificationCode('');
    }
  };

  useEffect(() => {
    if (verificationCode.length === 6) {
      handleVerificationSubmit();
    }
  }, [verificationCode]);

  const formatPhoneNumber = (value) => {
    if (!value) return value;
    const phoneNumber = value.replace(/[^\d+]/g, '');
    if (phoneNumber.startsWith('44')) return `+${phoneNumber}`;
    if (phoneNumber.startsWith('65')) return `+${phoneNumber}`;
    if (phoneNumber.startsWith('4')) return `+4${phoneNumber}`;
    if (phoneNumber.startsWith('6')) return `+6${phoneNumber}`;
    return phoneNumber;
  };

  const handlePhoneChange = (e) => {
    const formattedPhone = formatPhoneNumber(e.target.value);
    setIdentifier(formattedPhone);
  };

  const handleHandleSubmit = async () => {
    try {
      const response = await axios.post('/api/v1/auth/create_handle', {
        handle,
        phone: identifier
      });

      if (response.data.status === 'success') {
        window.location.href = response.data.redirect_to;
      }
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to create handle');
    }
  };

  const renderVerificationStep = () => (
    <div className="min-h-screen bg-gray-900 text-white flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="mb-8 flex justify-center">
          <div className="w-16 h-16 rounded-full bg-teal-500 flex items-center justify-center text-xl font-bold">
            {handle ? handle[1].toUpperCase() : 'S'}
          </div>
        </div>

        <h1 className="text-2xl font-bold text-center mb-2">
          {isQuickVerification ? `Welcome back, ${handle}` : (handle ? `Welcome back, ${handle}` : 'Verify your number')}
        </h1>
        
        {isQuickVerification && (
          <p className="text-gray-400 text-center mb-4">
            Quick verification required
          </p>
        )}
        
        <div className="flex justify-center space-x-4 mb-12">
          {[...Array(6)].map((_, i) => (
            <div key={i} 
                 className={`w-3 h-3 rounded-full ${
                   i < verificationCode.length ? 'bg-white' : 'bg-gray-600'
                 }`} 
            />
          ))}
        </div>

        <div className="grid grid-cols-3 gap-6 mb-8">
          {[1,2,3,4,5,6,7,8,9,'',0,'⌫'].map((num, i) => (
            <button
              key={i}
              onClick={() => {
                if (num === '⌫') {
                  setVerificationCode(prev => prev.slice(0, -1));
                } else if (num !== '') {
                  setVerificationCode(prev => prev.length < 6 ? prev + num : prev);
                }
              }}
              className={`h-14 text-2xl font-light rounded-full
                ${num === '' ? 'cursor-default' : 'hover:bg-gray-800 active:bg-gray-700'}`}
            >
              {num}
            </button>
          ))}
        </div>

        {error && (
          <div className="text-red-500 text-center mb-4 flex items-center justify-center">
            <span>{error}</span>
            <button onClick={() => setError('')} className="ml-2">
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        <button 
          className="text-sm text-gray-400 w-full text-center mt-4"
          onClick={() => {
            setStep('initial');
            setVerificationCode('');
            setIsQuickVerification(false);
          }}
        >
          Didn't receive code?
        </button>
      </div>
    </div>
  );

  const renderInitialStep = () => (
    <div className="min-h-screen bg-gray-900 text-white flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-md space-y-8">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-2">Welcome to SuperApp</h1>
          <p className="text-gray-400">Enter your phone number or @handle</p>
        </div>

        <div>
          <input
            type="text"
            value={identifier}
            onChange={handlePhoneChange}
            placeholder="+44, +65, or @handle"
            className="w-full bg-gray-800 border-0 rounded-lg py-4 px-6 text-lg 
                     focus:ring-2 focus:ring-teal-500 focus:outline-none"
          />
        </div>

        {error && (
          <div className="text-red-500 text-center flex items-center justify-center">
            <span>{error}</span>
            <button onClick={() => setError('')} className="ml-2">
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        <button
          onClick={handleSubmit}
          disabled={!identifier}
          className="w-full bg-teal-500 text-white rounded-lg py-4 font-medium
                   disabled:opacity-50 disabled:cursor-not-allowed
                   hover:bg-teal-600 transition-colors"
        >
          Continue
        </button>
      </div>
    </div>
  );

  const renderHandleCreation = () => (
    <div className="min-h-screen bg-gray-900 text-white flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-md space-y-8">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-2">Create your handle</h1>
          <p className="text-gray-400">This will be your unique identifier</p>
        </div>

        <div>
          <input
            type="text"
            value={handle}
            onChange={(e) => setHandle(e.target.value.startsWith('@') ? e.target.value : '@' + e.target.value)}
            placeholder="@username"
            className="w-full bg-gray-800 border-0 rounded-lg py-4 px-6 text-lg 
                     focus:ring-2 focus:ring-teal-500 focus:outline-none"
          />
        </div>

        {error && (
          <div className="text-red-500 text-center flex items-center justify-center">
            <span>{error}</span>
            <button onClick={() => setError('')} className="ml-2">
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        <button
          onClick={handleHandleSubmit}
          disabled={!handle || handle.length < 2}
          className="w-full bg-teal-500 text-white rounded-lg py-4 font-medium
                   disabled:opacity-50 disabled:cursor-not-allowed
                   hover:bg-teal-600 transition-colors"
        >
          Create Handle
        </button>
      </div>
    </div>
  );

  return (
    <>
      {step === 'checking' && (
        <div className="min-h-screen bg-gray-900 flex items-center justify-center">
          <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-teal-500" />
        </div>
      )}
      {step === 'initial' && renderInitialStep()}
      {step === 'verify' && renderVerificationStep()}
      {step === 'create_handle' && renderHandleCreation()}
    </>
  );
};

export default UnifiedLogin;
