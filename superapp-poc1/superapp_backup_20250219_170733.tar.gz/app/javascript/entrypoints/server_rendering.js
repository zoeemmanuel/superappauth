import React from 'react'
import ReactDOMServer from 'react-dom/server'
import UnifiedLogin from '../components/auth/UnifiedLogin'

global.React = React
global.ReactDOMServer = ReactDOMServer
global.UnifiedLogin = UnifiedLogin
