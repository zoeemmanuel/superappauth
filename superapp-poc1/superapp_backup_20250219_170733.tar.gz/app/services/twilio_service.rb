class TwilioService
  class << self
    def send_sms(to, body)
      Rails.logger.info "Attempting to send SMS to #{to}"
      Rails.logger.info "Using Twilio credentials: SID=#{ENV['TWILIO_ACCOUNT_SID']}, FROM=#{ENV['TWILIO_PHONE_NUMBER']}"
      
      client.messages.create(
        from: ENV['TWILIO_PHONE_NUMBER'],
        to: to,
        body: body
      )
      Rails.logger.info "SMS sent successfully"
      true
    rescue Twilio::REST::RestError => e
      Rails.logger.error "Twilio Error: #{e.message}"
      Rails.logger.error e.backtrace.join("\n")
      false
    rescue => e
      Rails.logger.error "Unexpected error sending SMS: #{e.message}"
      Rails.logger.error e.backtrace.join("\n")
      false
    end

    private

    def client
      @client ||= begin
        Rails.logger.info "Initializing Twilio client"
        Twilio::REST::Client.new(
          ENV['TWILIO_ACCOUNT_SID'],
          ENV['TWILIO_AUTH_TOKEN']
        )
      end
    end
  end
end
