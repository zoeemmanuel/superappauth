const esbuild = require('esbuild')

esbuild.build({
  entryPoints: ['app/javascript/application.js'],
  bundle: true,
  sourcemap: true,
  outdir: 'app/assets/builds',
  publicPath: '/assets',
  loader: {
    '.js': 'jsx',
    '.jsx': 'jsx'
  },
  resolveExtensions: ['.js', '.jsx'],
  target: ['es2015']
}).catch(() => process.exit(1))
