Rails.application.config.cache_store = :memory_store, { size: 64.megabytes }
