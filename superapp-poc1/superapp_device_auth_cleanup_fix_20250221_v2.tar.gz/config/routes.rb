Rails.application.routes.draw do
  # API routes
  namespace :api do
    namespace :v1 do
      resources :auth, only: [] do
        collection do
          post :check_device
          post :verify_login
          post :verify_code
          post :create_handle
          get :check_status
        end
      end
    end
  end

  # Main routes
  get 'dashboard', to: 'dashboard#index'
  delete 'logout', to: 'dashboard#logout'
  delete 'reset_devices', to: 'dashboard#reset_devices'
  put 'update_handle', to: 'dashboard#update_handle'
  root 'auth#login'
end
