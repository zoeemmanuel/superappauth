class AuthController < ApplicationController
  def login
    render layout: 'auth'
  end
end
